
@extends('student.master')

@section('title')
IDP | Students
@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            List of Students
            <small>advanced tables</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{action('CalendarController@index')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">List of students</li>
        </ol>
    </section>
    <div class="modal fade" id="modal-attendance">
        <div class="modal-dialog">
            <div class="modal-content" style="height:auto;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><b>Mark attendance</b></h4>
                </div>
                <div class="modal-body">
                    <div class="bo">
                        <div class="box-header with-border">
                            <h3 class="box-title">Attendance for SSS1(A) - 21/06/17</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Name</th>
                                        <th>Attendance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            1
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            2
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red"> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            3
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            4
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            5
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tfoot>
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Name</th>
                                            <th>Attendance</th>
                                        </tr>
                                    </tfoot>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <!-- /.box -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <div class="modal fade" id="modal-timetable">
        <div class="modal-dialog">
            <div class="modal-content" style="height:auto;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><b>Mark attendance</b></h4>
                </div>
                <div class="modal-body">
                    <div class="bo">
                        <div class="box-header with-border">
                            <h3 class="box-title">Attendance for SSS1(A) - 21/06/17</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example4" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Name</th>
                                        <th>Attendance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            1
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            2
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red"> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            3
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            4
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            5
                                        </td>
                                        <td>Komolafe Dayo</td>

                                        <td>
                                            <input type="checkbox" class="flat-red" checked> Present


                                        </td>
                                    </tr>
                                    <tfoot>
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Name</th>
                                            <th>Attendance</th>
                                        </tr>
                                    </tfoot>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <!-- /.box -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
            <div class="modal-content" style="height:800px">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Student Information</h4>
                </div>
                <div class="modal-body">
                    <div class="box box-widget widget-user">
                        <!-- Add the bg color to the header using any of the bg-* classes -->
                        <div class="widget-user-header bg-aqua-active">
                            <h3 class="widget-user-username nm">Ayodele Dayo</h3>
                            <h5 class="widget-user-desc">Student</h5>
                        </div>
                        <div class="widget-user-image">
                            <img class="img-circle" src="dist/img/user1-128x128.jpg" alt="User Avatar">
                        </div>
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-sm-4 border-right">
                                    <div class="description-block">
                                        <h5 class="description-header cl">SSS2</h5>
                                        <span class="description-text">CLASS</span>
                                    </div>
                                    <!-- /.description-block -->
                                </div>
                                <!-- /.col -->
                                <div class="col-sm-4 border-right">
                                    <div class="description-block">
                                        <h5 class="description-header gn">MALE</h5>
                                        <span class="description-text">GENDER</span>
                                    </div>
                                    <!-- /.description-block -->
                                </div>
                                <!-- /.col -->
                                <div class="col-sm-4">
                                    <div class="description-block">
                                        <h5 class="description-header ag">15</h5>
                                        <span class="description-text">AGE</span>
                                    </div>
                                    <!-- /.description-block -->
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->
                        </div>
                    </div>
                    <!-- /.widget-user -->

                    <table class="table table-striped">
                        <tr>
                            <th>Followings</th>
                            <th>Details</th>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td class="nm">Adedayo Ayomide</td>

                        </tr>
                        <tr>
                            <td>Class</td>
                            <td class="cl">SSS2</td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td class="gn">SSS2</td>
                        </tr>
                        <tr>
                            <td>Admission Number</td>
                            <td class="an">SSS2</td>
                        </tr>
                        <tr>
                            <td>Admission Date</td>
                            <td class="ad">SSS2</td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Delete student</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-search"></i> Select Criteria</h3>
                        </div>
                        <div class="box-body">
                            <div class="">
                                <div class="col-md-6">
                                    <form id="search_by_class_form" role="form" action="search" method="post" class="form-horizontal">
                                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                                        <input type="hidden" name="ci_csrf_token" value="">
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <label>Class</label>
                                                <select id="class_id" name="class_id" class="form-control">
                                                <option value="">Select</option>
                                                @foreach($classes as $class)
                                                {
                                                    <option value="{!! $class->name !!}">{!! $class->name !!}</option>
                                                }
                                                @endforeach
                                                </select>
                                                <span class="text-danger"></span>
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Section</label>
                                                <select id="section" name="section" class="form-control">
                                                <option value="All">All</option>
                                                <option value="A">A</option>
                                                <option value="B">B</option>
                                                <option value="C">C</option>
                                                <option value="D">D</option>                                               
                                            </select>
                                                <span class="text-danger"></span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" name="submit" value="search_class" class="btn btn-primary btn-sm pull-right checkbox-toggle"><i class="fa fa-search"></i> Search</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!--<div class="col-md-6">
                                    <form role="form" action="student/search" method="post" class="form-horizontal">
                                        <input type="hidden" name="ci_csrf_token" value="">
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label>Search By Keyword</label>
                                                <input type="text" name="search_text" class="form-control" placeholder="Search By Name, Roll Number, Enroll Number, National Id, Local Id Etc..">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" name="submit" value="search_particular" class="btn btn-primary pull-right btn-sm checkbox-toggle"><i class="fa fa-search"></i> Search</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>-->
                            </div>
                        </div>
                    </div>
                    
                    <div class="box box-primary" id="table-con-box">
                        <div class="box-header">
                            <h3 class="box-title">Data Table With Full Features</h3>
                            <button data-toggle="modal" data-target="#modal-attendance" type="button" class="btn btn-success pull-right">Mark Attendance</button>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive ">
                            <table id="example1" class="students-table table table-bordered table-striped">

                                <thead>
                                    <tr>
                                        <th>Image</th>


                                        <th>Admission Number</th>
                                        <th>Full name</th>
                                        <th>Class</th>
                                        <th>Gender</th>
                                        <th>Date of birth</th>
                                        <th>Address</th>
                                        <th>Admission year</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class=" ">
                                    @foreach($students as $student)
                                    <tr>
                                    <td>
                                    <img src="{{url('/images/')}}/{{$student->image}}" width="40" height="40"/>
                                    </td>

                                    <td>{!! $student->admission_no !!} </td>
                                    <td>{!! $student->firstname !!} {{ $student->lastname}}</td>
                                    <td>{!! $student->name !!} {{$student->section}} </td>
                                    <td>{!! $student->gender !!} </td>
                                    <td>{!! $student->date_of_birth !!} </td>
                                    <td>{!! $student->current_address !!} </td>
                                    <td>{!! $student->admission_date !!} </td>
                                    <td class="pull-right">
                                    <a data-toggle="moda" data-target="#modal-defaul" href="{!! action('StudentController@show', $student->stud_id) !!}" class="btn btn-default btn-xs" data-toggle="tooltip" title="" data-original-title="Show">
                                    <i class="fa fa-reorder"></i>
                                    </a>
                                    <a href="{!! action('StudentController@edit_form', $student->stud_id) !!}" class="btn btn-default btn-xs" data-toggle="tooltip" title="" data-original-title="Edit">
                                    <i class="fa fa-pencil"></i>
                                    </a>
                                    </td>
                                    </tr>
                                    @endforeach

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Image</th>


                                        <th>Admission Number</th>
                                        <th>Full name</th>
                                        <th>Class</th>
                                        <th>Gender</th>
                                        <th>Date of birth</th>
                                        <th>Address</th>
                                        <th>Admission year</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                                </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                    

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>


@endsection
