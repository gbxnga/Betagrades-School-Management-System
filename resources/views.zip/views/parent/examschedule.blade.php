<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <table class="">
                <tbody>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Subject</th>
                        <th>Action</th>
                        <th style="width: 40px">Action</th>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td>ENGLISH LANGUAGE</td>
                        <td></td>
                        <td></td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>
</section>