@extends('student.master')

@section('title')
Class
@endsection
@section('content')

<div class="content-wrapper" style="min-height: 681px;">

    <section class="content-header">
        <h1>
            <i class="fa fa-mortar-board"></i> Academics </h1>
    </section>


<section class="content">
        <div class="row">
        <div class="col-md-12">
        @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
        @endif 
        @if (count($errors) > 0) 
        @foreach ($errors->all() as $error)

            <li>{{ $error }}</li>

        @endforeach 
        @endif
        <?php
            if (isset($edit) && !empty($edit)){
                $editmode = true;
            }else {$editmode = false;}
        ?>
                    </div>    
            <div class="col-md-4">           
                <div class="box box-primary">
                    <div class="box-header with-border">
                    <?php
                    if ($editmode){
                        echo '<h3 class="box-title">Edit Teacher</h3>';
                    }else{ echo '<h3 class="box-title">Add Teacher</h3>';}
                    ?>
                    </div> 
                    <form id="form1" name="employeeform" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <div class="box-body">
                              <input type="hidden" name="_token" value="{!! csrf_token() !!}">      
                                                         <div class="form-group">
                                <label for="exampleInputEmail1">Teacher Name</label>
                                <input id="category" name="name"
                                <?php
                                if ($editmode)
                                {
                                    echo 'value="'.$teacher['name'].'"';
                                }
                                ?>
                                 placeholder="" type="text" class="form-control">
                                <span class="text-danger"></span>
                            </div>
                             <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input id="" name="username"
                                <?php
                                if ($editmode)
                                {
                                    echo 'value="'.$teacher['username'].'"';
                                }
                                ?>
                                 placeholder="" type="text" class="form-control">
                                <span class="text-danger"></span>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input id="category" name="email"
                                <?php
                                if ($editmode)
                                {
                                    echo 'value="'.$teacher['email'].'"';
                                }
                                ?>
                                 placeholder="" type="text" class="form-control">
                                <span class="text-danger"></span>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile"> Gender &nbsp;&nbsp;</label>
                                <select class="form-control" name="sex">
                                    <option value="">Select</option>
                                            <option
                                            <?php 
                                            if ($editmode)
                                            {
                                                if($teacher['sex'] === 'Male')
                                                echo 'selected="selected"';
                                            } 
                                            ?>
                                            value="Male">Male</option>
                                            <option
                                            <?php 
                                            if ($editmode)
                                            {
                                                
                                                if($teacher['sex'] === 'Female')
                                                echo 'selected="selected"';
                                            } 
                                            ?>
                                             value="Female">Female</option>
                                    </select>
                                <span class="text-danger"></span>
                            </div>
                            <!--<div class="form-group">
                                <label for="exampleInputEmail1">Date Of Birth</label>
                                <input id="dob" name="dob"
                                <?php
                                if ($editmode)
                                {
                                    echo 'value="'.$teacher['dob'].'"';
                                }
                                ?>
                                 placeholder="" type="text" class="form-control" value="" readonly="readonly">
                                <span class="text-danger"></span>
                            </div>-->
                             <?php
                                if (!($editmode))
                                {
                                ?>
                                <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input id="password" name="password" placeholder="" type="text" class="form-control">
                                <span class="text-danger"></span>
                            </div>
                                <?php
                                }
                                ?>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Address</label>
                                <textarea id="address" name="address" placeholder="" class="form-control">
                                <?php
                                if ($editmode)
                                {
                                    echo $teacher['address'];
                                }
                                ?>
                                </textarea>
                                <span class="text-danger"></span>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Phone</label>
                                <input id="phone" name="phone"
                                <?php
                                if ($editmode)
                                {
                                    echo 'value="'.$teacher['phone'].'"';
                                }
                                ?>
                                 placeholder="" type="text" class="form-control">
                                <span class="text-danger"></span>
                            </div>
                            <div class="form-group">
                                            <label for="exampleInputEmail1">Class Teacher</label>
                                            <select id="class_id" name="class_id" class="form-control">
                                                <option value="">Select Class</option>
                                                <?php
                                                ?>
                                                @foreach($classes as $class)
                                                {
                                                    <option value="{!! $class->id !!}">{!! $class->name !!} - {{$class->section}}</option>
                                                }
                                                @endforeach
                                                </select>
                                            <span class="text-danger"></span>
                                        </div>
                            <div class="form-group">
                                <label for="exampleInputFile">Teacher Photo (150px X 150px)</label>
                                <input type="file" name="image" id="image" size="20">

                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-info pull-right">Save</button>
                        </div>
                    </form>
                </div>   
            </div>  
            <div class="col-md-8">              
                <div class="box box-primary" id="tachelist">
                    <div class="box-header ptbnull">
                        <h3 class="box-title titlefix">Teacher List</h3>
                    </div>
                    <div class="box-body">
                        <div class="mailbox-controls">
                        </div>
                        <div class="table-responsive mailbox-messages">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer"><div class="dt-buttons btn-group btn-group2"><a class="btn btn-default buttons-copy buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="Copy"><span><i class="fa fa-files-o"></i></span></a><a class="btn btn-default buttons-excel buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="Excel"><span><i class="fa fa-file-excel-o"></i></span></a><a class="btn btn-default buttons-csv buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="CSV"><span><i class="fa fa-file-text-o"></i></span></a><a class="btn btn-default buttons-pdf buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="PDF"><span><i class="fa fa-file-pdf-o"></i></span></a><a class="btn btn-default buttons-print" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="Print"><span><i class="fa fa-print"></i></span></a><a class="btn btn-default buttons-collection buttons-colvis" tabindex="0" aria-controls="DataTables_Table_0" href="#" title="Columns"><span><i class="fa fa-columns"></i></span></a></div><div class="row"><div class="col-sm-6 pull-right22"><div id="DataTables_Table_0_filter" class="dataTables_filter"><label><input type="search" class="form-control" placeholder="Search..." aria-controls="DataTables_Table_0"></label></div></div></div><div class="row"><div class="col-sm-12"><table class="table table-striped table-bordered table-hover example dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                                <thead>
                                    <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Teacher Name: activate to sort column descending" style="width: 189px;">Teacher Name</th><th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending" style="width: 183px;">Email</th><th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Date Of Birth: activate to sort column ascending" style="width: 92px;">Date Of Birth</th><th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 93px;">Phone</th><th class="text-right no-print sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Action                                        : activate to sort column ascending" style="width: 83px;">Action                                        </th></tr>
                                </thead>
                                <tbody>
                                     @foreach($teachers as $teacher)
                                    <tr>
                                    <td>{!! $teacher->name !!}</td>
                                    <td>{!! $teacher->email !!} </td>
                                    <td>{!! $teacher->dob !!} </td>
                                    <td>{!! $teacher->phone !!} </td>
                                    <td class="mailbox-date pull-right">
                                    <a data-toggle="moda" data-target="#modal-defaul" href="{!! action('TeacherController@show', $teacher->id) !!}" class="btn btn-default btn-xs" data-toggle="tooltip" title="" data-original-title="Show">
                                    <i class="fa fa-reorder"></i>
                                    </a>
                                                <a href="{!! action('TeacherController@edit', $teacher->id) !!}" class="btn btn-default btn-xs " data-toggle="tooltip " title="Edit ">
                                                    <i class="fa fa-pencil "></i>
                                                </a>
                                                <a href="{!! action('TeacherController@delete', $teacher->id) !!}" class="btn btn-default btn-xs " data-toggle="tooltip " title="Delete " onclick="return confirm( 'Are you sure you want to delete this item?'); ">
                                                    <i class="fa fa-remove "></i>
                                                </a>
                                                </td>
                                    </tr>
                                    @endforeach                                            
</tbody>
                            </table></div></div><div class="row"><div class="col-sm-12"><div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">Showing 1 to 10 of 10 entries</div></div><div class="col-sm-12"><div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate"><ul class="pagination"><li class="paginate_button previous disabled" id="DataTables_Table_0_previous"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="0" tabindex="0"><i class="fa fa-angle-left"></i></a></li><li class="paginate_button active"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="1" tabindex="0">1</a></li><li class="paginate_button next disabled" id="DataTables_Table_0_next"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="2" tabindex="0"><i class="fa fa-angle-right"></i></a></li></ul></div></div></div></div>
                        </div>
                    </div>
                    <div class="">
                        <div class="mailbox-controls">
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </section>

            </div>   <!-- /.row -->
    </section><!-- /.content -->
    @endsection